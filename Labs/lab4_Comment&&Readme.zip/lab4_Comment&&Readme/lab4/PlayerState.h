enum player_status{
	not_set,
	bet,
	fold,
	check,
	call, 
	raise,
	out_of_round,
	chip_run_out
};