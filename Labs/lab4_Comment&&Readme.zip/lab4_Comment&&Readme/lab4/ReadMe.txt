========================================================================
    CONSOLE APPLICATION : lab4 Project Overview
========================================================================



















/////////////////////////////////////////////////////////////////////////////
                            Things to work on
/////////////////////////////////////////////////////////////////////////////

1. current chips < bet value
2. raise or bet can only be 1 or 2
3. user input can only be bet,check,raise,call,or fold
4. when player is out of chips, skip him
5. last requirement, print info about folded player
6. split value is double
7. player add chips to pot if fold??