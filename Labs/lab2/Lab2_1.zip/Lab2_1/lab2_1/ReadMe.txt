1. why need destructor
2. should shuffle return void or int
3. 