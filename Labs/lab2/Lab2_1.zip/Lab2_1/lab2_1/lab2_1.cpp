// lab2_1.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Deck.h"
#include "Hand.h"
using namespace std;




bool poker_rank(const Hand & lhand, const Hand & rhand){
	map<Hand_rank, string> trans_hand;
	trans_hand[unranked] = "Unranked";
	trans_hand[one_pair] = "One Pair";
	trans_hand[two_pars] = "Two pairs";
	trans_hand[three_of_kind] = "Three of a kind";
	trans_hand[full_house] = "Full House";
	trans_hand[fourofkind] = "Four of a kind";
	trans_hand[straight_] = "Straight";
	trans_hand[flush_] = "Flush";
	trans_hand[straight_flush] = "Straight Flush";

	Hand_rank left_handrank = lhand.rank();
	Hand_rank right_handrank = rhand.rank();



	//this->hand_.size() -1 gives the index of the largest element (since sorted ascendingly)
	//the other ints are initialized with the same reason
	int max_index = (lhand).size() - 1;
	int second_largest_index = (lhand).size() - 2;
	int third_largest_index = (lhand).size() - 3;
	int fourth_largest_index = (lhand).size() - 4;
	int fifth_largest_index = (lhand).size() - 5;
	//Compares the rank of hands
	if (left_handrank != right_handrank){
		return left_handrank < right_handrank;
	}
	// if hand rank is the same, there are following cases

	else{
		// if the rank of hands are straihgt, straight flush, flush, or unranked, we simply compared the last card's rank (largest since sorted)
		if (left_handrank == straight_flush || flush_ || straight_ || unranked){
			return lhand.reversecomp( rhand );
		}
		// if not one of above, we initialize a frequency table for this hand and another hand
		else{
			vector<int> lefthand_frequencyTable(lhand.size());

			//create frequency table for this hand
			for (int i = 0; i < valid_hand_size; i++){
				int leading_count = 1;

				for (int j = i + 1; j < valid_hand_size; j++){


					if (lhand.hand_[i].rank_ == lhand.hand_[j].rank_) {

						leading_count++;
					}
				}
				lefthand_frequencyTable[i] = leading_count;
			}

			vector<int> righthand_frequencyTable(rhand.size());

			//create frequency table for another hand
			for (int i = 0; i < valid_hand_size; i++){
				int leading_count = 1;

				for (int j = i + 1; j < valid_hand_size; j++){


					if (rhand.hand_[i].rank_ == rhand.hand_[j].rank_) {

						leading_count++;
					}
				}
				righthand_frequencyTable[i] = leading_count;
			}


			//for four of a kind, we find the last index of the group of fourcard and the index of the individual card
			// then compare the rank of group of four card, if equal compare the rank of inidivdual card
			if (left_handrank == fourofkind){

				// initialize intergers gonna be sued
				int this_lastofgroup_index = 0;
				int this_thehighestindividual_index = 0;
				int another_lastofgroup_index = 0;
				int another_thehighestindividual_index = 0;

				//find the last index of the group of four cards for this hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frquency_fourofakind){
						this_lastofgroup_index = i;
					}
				}

				//find the index of individual card for this hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_none){
						this_thehighestindividual_index = i;
						break;
					}
				}

				//find the last index of the group of four cards for another hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frquency_fourofakind){ another_lastofgroup_index = i; }
				}

				//find the index of individual card for another hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_none){
						another_thehighestindividual_index = i;
						break;
					}
				}

				// then compare the rank of group of four card, if equal compare the rank of inidivdual card

				if( lhand.hand_[this_lastofgroup_index].rank_ == rhand.hand_[another_lastofgroup_index].rank_){ return lhand.hand_[this_thehighestindividual_index].rank_ < rhand.hand_[another_thehighestindividual_index].rank_; }
				else{ return lhand.hand_[this_lastofgroup_index].rank_ < rhand.hand_[another_lastofgroup_index].rank_; }


			}
			// if it is three of a kind 
			// we use the exact same logic
			if (left_handrank == three_of_kind){
				int this_lastofgroup_index = 0;
				int this_thehighestindividual_index = 0;
				int another_lastofgroup_index = 0;
				int another_thehighestindividual_index = 0;

				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_threeofakind){ this_lastofgroup_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_none){ this_thehighestindividual_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_threeofakind){ another_lastofgroup_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_none){ another_thehighestindividual_index = i; }
				}
				if (lhand.hand_[this_lastofgroup_index].rank_ == rhand.hand_[another_lastofgroup_index].rank_){ return lhand.hand_[this_thehighestindividual_index].rank_ < rhand.hand_[another_thehighestindividual_index].rank_; }
				else{ return lhand.hand_[this_lastofgroup_index].rank_ < rhand.hand_[another_lastofgroup_index].rank_; }

			}
			// if it is two pairs, we need to get the index of the first pair and the second pair. and the index of the individual card
			if (left_handrank == two_pars){

				//ints intiailized for future uses
				int this_lastofgroup_index = 0;
				int this_firstpair_lastofgroup_index = 0;
				int this_thehighestindividual_index = 0;
				int another_lastofgroup_index = 0;
				int another_thehighestindividual_index = 0;
				int another_firstpair_lastofgroup_index = 0;

				// find the index of the highest pair for this hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_twopairs){ this_lastofgroup_index = i; }
				}
				//find the index of the second pair for this hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_none){ this_thehighestindividual_index = i; }
				}
				// find the index of the individual card for this hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_none){ this_firstpair_lastofgroup_index = i; break; }
				}
				// do same things for another hand
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_twopairs){ another_lastofgroup_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_none){ another_thehighestindividual_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_none){ another_firstpair_lastofgroup_index = i; break; }
				}
				// if first and second pairs are all with same ranks, compare the indivudual card
				// if first pair is the same, compare the second pair's rank
				// if the first pair is different in rank, compare them
				if (lhand.hand_[this_lastofgroup_index].rank_ == rhand.hand_[another_lastofgroup_index].rank_){
					if (lhand.hand_[this_firstpair_lastofgroup_index].rank_ == rhand.hand_[another_firstpair_lastofgroup_index].rank_){ return (lhand.hand_[this_thehighestindividual_index].rank_ < rhand.hand_[another_thehighestindividual_index].rank_); }
					return  lhand.hand_[this_firstpair_lastofgroup_index].rank_ < rhand.hand_[another_firstpair_lastofgroup_index].rank_;
				}
				else{ return lhand.hand_[this_thehighestindividual_index].rank_ < rhand.hand_[another_thehighestindividual_index].rank_; }
			}
			//this logic is the same as four of a kind
			if (left_handrank == full_house){
				int this_lastofgroup_index = 0;
				int this_firstpair_lastofgroup_index = 0;
				int another_lastofgroup_index = 0;
				int another_firstpair_lastofgroup_index = 0;
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_fullhouse_largest){ this_lastofgroup_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_fullhouse_secondlargest){ this_firstpair_lastofgroup_index = i; }
				}

				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_fullhouse_largest){ another_lastofgroup_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_fullhouse_secondlargest){ another_firstpair_lastofgroup_index = i; }
				}
				if (lhand.hand_[this_lastofgroup_index].rank_ == rhand.hand_[another_lastofgroup_index].rank_){ return lhand.hand_[this_firstpair_lastofgroup_index].rank_ < rhand.hand_[another_firstpair_lastofgroup_index].rank_; }
				else{ return lhand.hand_[this_lastofgroup_index].rank_ < rhand.hand_[another_lastofgroup_index].rank_; }
			}

			// this logic is the same as four of a kind
			if (left_handrank == one_pair){
				int this_lastofgroup_index = 0;
				int this_thehighestindividual_index = 0;
				int another_lastofgroup_index = 0;
				int another_thehighestindividual_index = 0;
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_onepair){
						this_lastofgroup_index = i;
					}
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (lefthand_frequencyTable[i] == frequency_none){
						this_thehighestindividual_index = i;
						break;
					}
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_onepair){ another_lastofgroup_index = i; }
				}
				for (int i = 0; i < valid_hand_size; ++i){
					if (righthand_frequencyTable[i] == frequency_none){
						another_thehighestindividual_index = i;
						break;
					}
				}

				if (lhand.hand_[this_lastofgroup_index].rank_ == rhand.hand_[another_lastofgroup_index].rank_){ return lhand.hand_[this_thehighestindividual_index].rank_ < rhand.hand_[another_thehighestindividual_index].rank_; }
				else{ return lhand.hand_[this_lastofgroup_index].rank_ < rhand.hand_[another_lastofgroup_index].rank_; }


			}
		}

	}

}












int usage_message(char* argv[], int number_of_argument, bool & will_be_shuffled, int & file_name_index){
	/*
	usage message" function that (1) prints out (to the program's standard output stream) the program's name followed by a helpful usage message
	telling the user how to run the program correctly (with the name of the program and the name of a file to read, e.g., lab0 card_file.txt),
	and (2) returns a non-zero value (int 2).*/
	will_be_shuffled = false;
	file_name_index = 1;
	if (number_of_argument > 3){
		cout << "more than 2 command line arguments are given" << endl;
		cout << "plesae enter a valid file name (file must be at the same directory) directly follow the program name using the command line or one more optional -shuffle argument (-shuffle and file name can be in either order)" << endl;
		cout << "for example: " << "lab2_1.exe card_file.txt shuffle" << endl;
		return morethantwo_argument;
	}
	else if (number_of_argument == 1){
		cout << "no command line arguments are given " << endl;
		cout << "plesae enter a valid file name (file must be at the same directory) directly follow the program name using the command line or one more optional -shuffle argument (-shuffle and file name can be in either order)" << endl;
		cout << "for example: " << "lab2_1.exe card_file.txt shuffle" << endl;
		return no_argument;
	}

	else if (number_of_argument == 2){
		if (argv[1] == "-shuffle"){
			cout << "only one command line argument is given but it contains  - shuffle.  " << endl;
			cout << "plesae enter a valid file name (file must be at the same directory) directly follow the program name using the command line or one more optional -shuffle argument (-shuffle and file name can be in either order)" << endl;
			cout << "for example: " << "lab2_1.exe card_file.txt shuffle" << endl;
			return onlyone_is_shuffle;
		}
		will_be_shuffled = false;
		file_name_index = 1;
		return Success_commandline;
	}
	else {
		for (int i = 0; i < number_of_argument; ++i){
			if (argv[i] == "-shuffle"){
				will_be_shuffled = true;
				file_name_index = i;
			}
		}
		if (!will_be_shuffled){
			cout << "two command line arguments are given but neither one contains - shuffle.   " << endl;
			cout << "plesae enter a valid file name (file must be at the same directory) directly follow the program name using the command line or one more optional -shuffle argument (-shuffle and file name can be in either order)" << endl;
			cout << "for example: " << "lab2_1.exe card_file.txt shuffle" << endl;
			return two_neither_shuffle;
		}
		return Success_commandline;
	}
    
}

int main(int argc, char* argv[])
{    	// check weather the commandline arugments are valid (length 2)
	/*
	if (argc != correct_number_of_arguments)
	{
	// if not, usage_message called to print out guidance for user and return the corresponding error type (int)
	int error = usage_message(argv[Program_name]);
	return error;
	}

	//the user passed in correct number of arguments
	else{

	Deck test_deck(argv[command_name]);

	cout << test_deck;
	}
	return SUCCESS;
	*/
	bool will_be_shuffled = false;
	int file_name_index = 1;
	int commandline_usermsg_result;
	commandline_usermsg_result = usage_message(argv, argc, will_be_shuffled, file_name_index);
	if (commandline_usermsg_result != Success_commandline){ return commandline_usermsg_result; }
	try{


		Deck deck(argv[file_name_index]); 
		//The program should then push back nine empty hand objects into an STL container (e.g., of type vector<Hand> or list<Hand>). 

		if (will_be_shuffled){
			deck.shuffle();
		}
		Hand hand;
		vector<Hand> Nine_hands(number_of_hands_inContainer, hand);
		//The program should then use the insertion operator you defined above to "deal" one card at a time from the deck to each of the nine hands in the container in turn, repeating the rotation until each of the hands has five cards. 


		if (deck.size() < minimum_cardsindeck_todealcards){
			cout << "Deck does not have at least 45 cards. Cannot start dealing cards process" << endl;
			return deck_not_atleast45cards;
		}



		bool not_allhands_full = true;

		while (deck.size() != 0 && not_allhands_full){

			for (unsigned int i = 0; i < Nine_hands.size(); ++i){
				Nine_hands[i] << deck;

			}

			for (unsigned int j = 0; j < Nine_hands.size(); ++j){
				if (Nine_hands[j].isnotfull()){
					not_allhands_full = true;
					break;
				}
				not_allhands_full = false;
			}


		}


		map<Hand_rank, string> trans_hand;
		trans_hand[unranked] = "Unranked";
		trans_hand[one_pair] = "One Pair";
		trans_hand[two_pars] = "Two pairs";
		trans_hand[three_of_kind] = "Three of a kind";
		trans_hand[full_house] = "Full House";
		trans_hand[fourofkind] = "Four of a kind";
		trans_hand[straight_] = "Straight";
		trans_hand[flush_] = "Flush";
		trans_hand[straight_flush] = "Straight Flush";
		//The program should then print out the contents of the deck object and the contents of each of the hand objects to which the cards were dealt. 
		cout << "Deck contents" << endl;
		cout << deck << endl;
		cout << "Each hand contents" << endl;
		for (size_t i = 0; i < Nine_hands.size(); i++)
		{
			cout << "/////////////////" << endl;
			cout << Nine_hands[i] << endl;
			cout << "////////////////" << endl;

		}
		cout << "After Sorting using member-method operator<" << endl;
		sort(Nine_hands.begin(), Nine_hands.end());
		for (size_t i = 0; i < Nine_hands.size(); i++)
		{
			
			cout << Nine_hands[i] << endl;
			

		}
		cout << "After using custom parse_rank function" << endl;
		sort(Nine_hands.begin(), Nine_hands.end(), poker_rank);
		for (size_t i = 0; i < Nine_hands.size(); i++)
		{
			
			cout << trans_hand[Nine_hands[i].rank()] << endl;
			cout << Nine_hands[i] << endl;
		

		}
	
	
	
	}
	catch (int i){
		return i;
	}
    
	
	/*
	map<Hand_rank, string> trans_hand;
	trans_hand[unranked] = "Unranked";
	trans_hand[one_pair] = "One Pair";
	trans_hand[two_pars] = "Two pairs";
	trans_hand[three_of_kind] = "Three of a kind";
	trans_hand[full_house] = "Full House";
	trans_hand[fourofkind] = "Four of a kind";
	trans_hand[straight_] = "Straight";
	trans_hand[flush_] = "Flush";
	trans_hand[straight_flush] = "Straight Flush";
	Hand hand;
	
	hand << deck;
	hand << deck;
	hand << deck;
	hand << deck;
	hand << deck;
	cout << hand << endl;
	cout << hand.asstring() << endl;
	cout << trans_hand[hand.rank()] << endl;
	return 0;
	*/
	
	return SUCCESS;

}


